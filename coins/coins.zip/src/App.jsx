import Coins from "./components/Coins"

function App() {
  return (
    <>
      <div>
         <Coins />
      </div>
    </>
  )
}

export default App
