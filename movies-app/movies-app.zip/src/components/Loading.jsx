const Loading = () => {
  return (
    <div className="d-flex justify-content-center align-items-center mt-5">
      <i className="fa-solid fa-rotate fa-spin fa-5x text-white"></i>
    </div>
  );
};
export default Loading;
